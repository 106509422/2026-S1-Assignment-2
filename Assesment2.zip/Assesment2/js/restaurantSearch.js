fetch('json/restaurants.json')
  .then(response => response.json())
  .then(data => {
    window.restaurants = data;
    displayRestaurants(data);
    setupFilters();

    document.getElementById('nameSearch').addEventListener('input', function() {
      const query = this.value.toLowerCase();
      const filtered = window.restaurants.filter(r => r.name.toLowerCase().includes(query));
      displayRestaurants(filtered);
    });

    document.getElementById('tagSearch').addEventListener('input', function() {
      const query = this.value.toLowerCase();
      const filtered = window.restaurants.filter(r => {
        const tags = [
          ...r.dietaryOptions,
          ...r.diningPurpose,
          r.cuisineType
        ].map(tag => tag.toLowerCase());
        return tags.some(tag => tag.includes(query));
      });
      displayRestaurants(filtered);
    });

    document.getElementById('priceMin').addEventListener('input', applyFilters);
    document.getElementById('priceMax').addEventListener('input', applyFilters);

    document.getElementById('sortPriceAsc').addEventListener('click', () => {
      data.sort((a, b) => priceSymbolToNumber(a.price) - priceSymbolToNumber(b.price));
      displayRestaurants(data);
    });
    document.getElementById('sortPriceDesc').addEventListener('click', () => {
      data.sort((a, b) => priceSymbolToNumber(b.price) - priceSymbolToNumber(a.price));
      displayRestaurants(data);
    });
  })
  .catch(error => {
    console.error('Error loading JSON:', error);
  });

function priceSymbolToNumber(priceSymbol) {
  return priceSymbol.length;
}

function displayRestaurants(data) {
  const container = document.getElementById('restaurantContainer');
  container.innerHTML = '';

  data.forEach(r => {
    const article = document.createElement('article');
    article.className = 'restaurant';

    const encodedName = encodeURIComponent(r.name);

    article.innerHTML = `
      <a href="${r.website}" target="_blank">
        <img src="${r.image}" alt="${r.name}">
      </a>
      <h3>${r.name}</h3>
      <p><strong>Location:</strong> ${r.location}</p>
      <p><strong>Price:</strong> ${r.price} (${priceSymbolToNumber(r.price)})</p>
      <p><strong>Rating:</strong> ${r.userRating}</p>
      <p><strong>Cuisine:</strong> ${r.cuisineType}</p>
      <p><strong>Signature Dish:</strong> ${r.signatureDish}</p>
      <p><strong>Description:</strong> ${r.description}</p>
      <button onclick="goToReservation('${encodedName}')">Reserve This</button>
    `;
    container.appendChild(article);
  });
}

function goToReservation(restaurantName) {
  window.location.href = `reservation.html?restaurant=${restaurantName}`;
}

function setupFilters() {
  // already setup above
}

function applyFilters() {
  const nameQuery = document.getElementById('nameSearch').value.toLowerCase();
  const tagQuery = document.getElementById('tagSearch').value.toLowerCase();
  const priceMin = parseInt(document.getElementById('priceMin').value);
  const priceMax = parseInt(document.getElementById('priceMax').value);

  const filtered = window.restaurants.filter(r => {
    const matchesName = r.name.toLowerCase().includes(nameQuery);
    const tags = [...r.dietaryOptions, ...r.diningPurpose, r.cuisineType].map(t => t.toLowerCase());
    const matchesTags = tags.some(t => t.includes(tagQuery));
    const priceLevel = priceSymbolToNumber(r.price);
    const minMatch = isNaN(priceMin) || priceLevel >= priceMin;
    const maxMatch = isNaN(priceMax) || priceLevel <= priceMax;
    return matchesName && matchesTags && minMatch && maxMatch;
  });
  displayRestaurants(filtered);
}

window.addEventListener('load', () => {
  applyFilters();
  preselectRestaurant();
});

function preselectRestaurant() {
  const params = new URLSearchParams(window.location.search);
  const restaurantName = params.get('restaurant');
  if (restaurantName) {
    const select = document.querySelector('#restaurant');
    if (select) {
      for (let i=0; i<select.options.length; i++) {
        if (select.options[i].value === restaurantName) {
          select.selectedIndex = i;
          break;
        }
      }
    }
  }
}