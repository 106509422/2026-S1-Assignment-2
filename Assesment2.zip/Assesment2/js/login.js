// Simulate login state
let isLoggedIn = true; // Change to true to simulate logged in
const username = "JohnDoe"; // Replace with actual username

const authLinkContainer = document.getElementById('authLink');

function updateAuthLink() {
  // Clear previous content
  authLinkContainer.innerHTML = '';

  if (isLoggedIn) {
    // Show username as plain text
    const span = document.createElement('span');
    span.textContent = username;
    authLinkContainer.appendChild(span);
  } else {
    // Show "Register" as a link
    const link = document.createElement('a');
    link.href = 'register.html'; // Change this to your login page URL
    link.textContent = 'Register';
    authLinkContainer.appendChild(link);
  }
}

// Run on page load
window.onload = updateAuthLink;