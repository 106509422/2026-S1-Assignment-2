function validate() {
  var username = document.getElementById("sid").value.trim();
  var pwd1 = document.getElementById("pwd1").value;
  var pwd2 = document.getElementById("pwd2").value;
  var email = document.getElementById("email").value.trim();
  var phone = document.getElementById("phone").value.trim();
  var country = document.getElementById("country").value;
  var genm = document.getElementById("genm").checked;
  var genf = document.getElementById("genf").checked;

  var errors = [];

  //all my validation checks
  if (username === "") {
    errors.push("Username cannot be empty.");
  }
  if (username.startsWith("@")) {
    errors.push("Username cannot start with '@'.");
  }
  if (username.length < 8) {
    errors.push("Username must be at least 8 characters.");
  }

  // Password validation
  if (pwd1 === "") {
    errors.push("Password cannot be empty.");
  }
  if (pwd2 === "") {
    errors.push("Retyped password cannot be empty.");
  }
  if (pwd1 !== pwd2) {
    errors.push("Passwords do not match.");
  }

if (email === "") {
  errors.push("Email cannot be empty.");
} else {
  var atCount = (email.match(/@/g) || []).length;
  if (atCount !== 1) {
    errors.push("Email must be valid");
  }
  if (email.indexOf(".") < 0) {
    errors.push("Email must be valid");
  }
}

  if (phone === "") {
    errors.push("Phone number cannot be empty.");
  } else {
    var phonePattern = /^[0-9]{10,15}$/;
    if (!phonePattern.test(phone)) {
      errors.push("Invalid phone number format.");
    }
  }

  if (country === "") {
    errors.push("Please select your country/region.");
  }

  if (!genm && !genf) {
    errors.push("A gender must be selected.");
  }

  //show errors in the box
  var errorBox = document.getElementById("errorBox");
  if (errors.length > 0) {
    errorBox.innerHTML = errors.join("<br>");
    errorBox.style.display = "block";
    return false; // prevent form submission
  } else {
    errorBox.style.display = "none"; // hide if no errors
    return true; // allow form submission
  }
}

document.getElementById("regform").onsubmit = validate;